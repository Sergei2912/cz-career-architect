# OpenClaw Documentation

Extracted documentation from [OpenClaw](https://github.com/openclaw/openclaw) - an open-source personal AI assistant framework.

## Contents

**230 markdown files** organized into 15 categories:

| Category | Files | Description |
|----------|-------|-------------|
| `01-core` | 10 | Getting started, setup, pairing |
| `02-installation` | 9 | npm, docker, nix, ansible |
| `03-configuration` | 3 | Gateway config, examples |
| `04-cli` | 36 | All CLI commands reference |
| `05-skills` | 23 | Skills system, tools, plugins |
| `06-channels` | 18 | WhatsApp, Telegram, Discord, Signal, etc. |
| `07-architecture` | 33 | Agent runtime, memory, sessions |
| `08-gateway` | 27 | Gateway protocols, security, APIs |
| `09-providers` | 15 | Anthropic, OpenAI, OpenRouter, etc. |
| `10-deployment` | 14 | Platform guides (Linux, macOS, Windows, Cloud) |
| `11-automation` | 8 | Hooks, cron jobs, webhooks |
| `12-nodes` | 7 | Media and device integrations |
| `13-web` | 5 | Control UI, dashboard, webchat |
| `14-reference` | 16 | Templates, RPC, technical reference |
| `15-help` | 6 | FAQ, troubleshooting, debugging |

## Structure

```
extracted/
├── 01-core/
│   ├── getting-started.md
│   ├── setup.md
│   └── ...
├── 02-installation/
├── 03-configuration/
├── ...
└── metadata.json          # RAG index with source URLs
```

## Usage

### For RAG/Training

Use `extracted/metadata.json` for indexing:

```json
{
  "documents": [
    {
      "id": "01-core/getting-started",
      "title": "Getting Started",
      "path": "01-core/getting-started.md",
      "source_url": "https://docs.openclaw.ai/start/getting-started",
      "category": "01-core"
    }
  ]
}
```

### Re-extract Documentation

```bash
# Clone OpenClaw source
git clone --depth 1 --filter=blob:none --sparse \
  https://github.com/openclaw/openclaw.git /tmp/openclaw-source
cd /tmp/openclaw-source && git sparse-checkout set docs

# Run extraction
node scripts/extract-docs.js
```

## Source

- **Original**: https://docs.openclaw.ai/
- **GitHub**: https://github.com/openclaw/openclaw
- **Extracted**: 2026-02-04

## License

Documentation content is from the OpenClaw project. See [OpenClaw License](https://github.com/openclaw/openclaw/blob/main/LICENSE).
