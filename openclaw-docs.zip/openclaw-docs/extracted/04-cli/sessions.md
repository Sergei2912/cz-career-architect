# `openclaw sessions`

List stored conversation sessions.

```bash
openclaw sessions
openclaw sessions --active 120
openclaw sessions --json
```