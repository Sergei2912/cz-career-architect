# `openclaw uninstall`

Uninstall the gateway service + local data (CLI remains).

```bash
openclaw uninstall
openclaw uninstall --all --yes
openclaw uninstall --dry-run
```