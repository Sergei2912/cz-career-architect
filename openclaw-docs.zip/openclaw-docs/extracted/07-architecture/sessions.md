# Sessions

Canonical session management docs live in [Session management](/concepts/session).